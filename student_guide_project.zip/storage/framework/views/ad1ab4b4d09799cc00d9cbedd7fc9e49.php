<?php $__env->startSection('title', 'إدارة مديري النظام'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-users-cog me-2"></i>إدارة مديري النظام</h1>
        <?php if(Auth::guard('admin_web')->user()->role === 'superadmin'): ?>
            <a href="<?php echo e(route('admin.admin-users.create')); ?>" class="btn btn-success">
                <i class="fas fa-user-plus me-1"></i> إضافة مدير جديد
            </a>
        <?php endif; ?>
    </div>

    

    <div class="card">
        <div class="card-body">
            <?php if($adminUsers->isEmpty()): ?>
                <div class="alert alert-info text-center">لا يوجد مديرو نظام لعرضهم حالياً.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>اسم المستخدم</th>
                                <th>الاسم (عربي)</th>
                                <th>البريد الإلكتروني</th>
                                <th>الدور</th>
                                <th>الحالة</th>
                                <th>تاريخ الإضافة</th>
                                <?php if(Auth::guard('admin_web')->user()->role === 'superadmin'): ?>
                                    <th>الإجراءات</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $adminUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adminUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($adminUser->id); ?></td>
                                <td><?php echo e($adminUser->username); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.admin-users.show', $adminUser)); ?>"><?php echo e($adminUser->name_ar); ?></a>
                                    <?php if($adminUser->name_en): ?> <small class="d-block text-muted"><?php echo e($adminUser->name_en); ?></small><?php endif; ?>
                                </td>
                                <td><?php echo e($adminUser->email); ?></td>
                                <td>
                                    <?php if($adminUser->role == 'superadmin'): ?>
                                        <span class="badge bg-danger">مدير عام</span>
                                    <?php elseif($adminUser->role == 'content_manager'): ?>
                                        <span class="badge bg-info">مدير محتوى</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e($adminUser->role); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($adminUser->is_active): ?>
                                        <span class="badge bg-success">نشط</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">غير نشط</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($adminUser->created_at->translatedFormat('Y-m-d')); ?></td>
                                <?php if(Auth::guard('admin_web')->user()->role === 'superadmin'): ?>
                                <td>
                                    <a href="<?php echo e(route('admin.admin-users.show', $adminUser)); ?>" class="btn btn-sm btn-info" title="عرض"><i class="fas fa-eye"></i></a>
                                    <a href="<?php echo e(route('admin.admin-users.edit', $adminUser)); ?>" class="btn btn-sm btn-primary" title="تعديل"><i class="fas fa-edit"></i></a>
                                    <?php if(Auth::guard('admin_web')->id() !== $adminUser->id && !($adminUser->role === 'superadmin' && App\Models\AdminUser::where('role', 'superadmin')->count() <= 1)): ?>
                                        <form action="<?php echo e(route('admin.admin-users.destroy', $adminUser)); ?>" method="POST" class="d-inline" onsubmit="return confirm('هل أنت متأكد من رغبتك في حذف هذا المدير؟');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" title="حذف"><i class="fas fa-trash"></i></button>
                                        </form>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-sm btn-danger disabled" title="لا يمكن حذف هذا المستخدم"><i class="fas fa-trash"></i></button>
                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <?php echo e($adminUsers->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/admin_users/index.blade.php ENDPATH**/ ?>