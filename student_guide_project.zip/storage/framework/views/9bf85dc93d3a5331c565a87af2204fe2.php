<?php $__env->startSection('title', 'إدارة طلبات تسجيل الفعاليات'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-clipboard-check me-2"></i>إدارة طلبات تسجيل الفعاليات</h1>
        
    </div>

    
    <div class="card mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.event-registrations.index')); ?>">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label for="event_id_filter" class="form-label">فلترة حسب الفعالية</label>
                        <select class="form-select form-select-sm" id="event_id_filter" name="event_id">
                            <option value="">-- كل الفعاليات --</option>
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($event->id); ?>" <?php echo e(request('event_id') == $event->id ? 'selected' : ''); ?>>
                                    <?php echo e($event->title_ar); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="status_filter" class="form-label">فلترة حسب الحالة</label>
                        <select class="form-select form-select-sm" id="status_filter" name="status">
                            <option value="">-- كل الحالات --</option>
                            <option value="pending_approval" <?php echo e(request('status', 'pending_approval') == 'pending_approval' ? 'selected' : ''); ?>>قيد المراجعة</option>
                            <option value="registered" <?php echo e(request('status') == 'registered' ? 'selected' : ''); ?>>مسجل/مقبول</option>
                            <option value="rejected" <?php echo e(request('status') == 'rejected' ? 'selected' : ''); ?>>مرفوض</option>
                            <option value="waitlisted" <?php echo e(request('status') == 'waitlisted' ? 'selected' : ''); ?>>قائمة انتظار</option>
                            <option value="attended" <?php echo e(request('status') == 'attended' ? 'selected' : ''); ?>>حضر</option>
                            <option value="cancelled_by_student" <?php echo e(request('status') == 'cancelled_by_student' ? 'selected' : ''); ?>>ملغى من الطالب</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary btn-sm w-100">فلترة</button>
                    </div>
                    <div class="col-md-2">
                        <a href="<?php echo e(route('admin.event-registrations.index')); ?>" class="btn btn-secondary btn-sm w-100">إعادة تعيين</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <?php if($registrations->isEmpty()): ?>
                <div class="alert alert-info text-center">
                    <?php if(request()->filled('event_id') || request()->filled('status')): ?>
                        لا توجد طلبات تسجيل تطابق معايير الفلترة الحالية.
                    <?php else: ?>
                        لا توجد طلبات تسجيل لعرضها حالياً (الطلبات قيد المراجعة تظهر بشكل افتراضي).
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>الفعالية</th>
                                <th>الطالب</th>
                                <th>الرقم الجامعي</th>
                                <th>تاريخ الطلب</th>
                                <th>الحالة</th>
                                <th>حضر؟</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($registration->id); ?></td>
                                <td>
                                    <?php if($registration->event): ?>
                                        <a href="<?php echo e(route('admin.events.show', $registration->event)); ?>"><?php echo e(Str::limit($registration->event->title_ar, 30)); ?></a>
                                    <?php else: ?>
                                        <span class="text-muted">فعالية محذوفة</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($registration->student): ?>
                                        <a href="<?php echo e(route('admin.students.show', $registration->student)); ?>"><?php echo e($registration->student->full_name_ar); ?></a>
                                    <?php else: ?>
                                        <span class="text-muted">طالب محذوف</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($registration->student->student_university_id ?? '-'); ?></td>
                                <td><?php echo e($registration->registration_datetime->translatedFormat('Y-m-d H:i')); ?></td>
                                <td>
                                    <?php if($registration->status == 'pending_approval'): ?>
                                        <span class="badge bg-warning text-dark">قيد المراجعة</span>
                                    <?php elseif($registration->status == 'registered' || $registration->status == 'approved'): ?>
                                        <span class="badge bg-success">مسجل/مقبول</span>
                                    <?php elseif($registration->status == 'rejected'): ?>
                                        <span class="badge bg-danger">مرفوض</span>
                                    <?php elseif($registration->status == 'waitlisted'): ?>
                                        <span class="badge bg-info">قائمة انتظار</span>
                                    <?php elseif($registration->status == 'cancelled_by_student'): ?>
                                        <span class="badge bg-secondary">ملغى من الطالب</span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-dark"><?php echo e($registration->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($registration->attended === true): ?>
                                        <span class="badge bg-primary">نعم</span>
                                    <?php elseif($registration->attended === false && ($registration->status == 'registered' || $registration->status == 'approved')): ?>
                                        <span class="badge bg-secondary">لم يحضر</span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.event-registrations.show', $registration)); ?>" class="btn btn-sm btn-info" title="عرض التفاصيل"><i class="fas fa-eye"></i></a>
                                    <?php if($registration->status == 'pending_approval'): ?>
                                        <form action="<?php echo e(route('admin.event-registrations.approve', $registration)); ?>" method="POST" class="d-inline ms-1">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-success" title="موافقة"><i class="fas fa-check"></i></button>
                                        </form>
                                        <button type="button" class="btn btn-sm btn-danger" title="رفض" data-bs-toggle="modal" data-bs-target="#rejectModal<?php echo e($registration->id); ?>"><i class="fas fa-times"></i></button>
                                        <!-- Modal للرفض -->
                                        <div class="modal fade" id="rejectModal<?php echo e($registration->id); ?>" tabindex="-1" aria-labelledby="rejectModalLabel<?php echo e($registration->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <form action="<?php echo e(route('admin.event-registrations.reject', $registration)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="rejectModalLabel<?php echo e($registration->id); ?>">رفض طلب تسجيل الطالب: <?php echo e($registration->student->full_name_ar ?? 'غير معروف'); ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>هل أنت متأكد من رفض طلب التسجيل هذا؟</p>
                                                            
                                                            
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                            <button type="submit" class="btn btn-danger">تأكيد الرفض</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <?php echo e($registrations->appends(request()->query())->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/event_registrations/index.blade.php ENDPATH**/ ?>