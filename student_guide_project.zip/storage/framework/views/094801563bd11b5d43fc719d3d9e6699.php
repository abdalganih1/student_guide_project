

<?php $__env->startSection('title', 'إدارة المقررات'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-book-open me-2"></i>إدارة المقررات</h1>
        <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus me-1"></i> إضافة مقرر جديد
        </a>
    </div>

    
    <div class="card mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.courses.index')); ?>">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label for="specialization_id_filter" class="form-label">فلترة حسب الاختصاص</label>
                        <select class="form-select" id="specialization_id_filter" name="specialization_id">
                            <option value="">-- كل الاختصاصات --</option>
                            <?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($specialization->id); ?>" <?php echo e(request('specialization_id') == $specialization->id ? 'selected' : ''); ?>>
                                    <?php echo e($specialization->name_ar); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">فلترة</button>
                    </div>
                    <div class="col-md-2">
                        <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn btn-secondary w-100">إعادة تعيين</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <?php if($courses->isEmpty()): ?>
                <div class="alert alert-info text-center">لا توجد مقررات لعرضها حالياً.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>الرمز</th>
                                <th>الاسم (عربي)</th>
                                <th>الاختصاص</th>
                                <th>الفصل/السنة</th>
                                <th>الساعات</th>
                                <th>تسجيل متاح</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($course->id); ?></td>
                                <td><?php echo e($course->code); ?></td>
                                <td><?php echo e($course->name_ar); ?></td>
                                <td><?php echo e($course->specialization->name_ar ?? 'غير محدد'); ?></td>
                                <td><?php echo e($course->semester_display_info); ?> <?php if($course->year_level): ?> (سنة <?php echo e($course->year_level); ?>) <?php endif; ?></td>
                                <td><?php echo e($course->credits ?: '-'); ?></td>
                                <td>
                                    <?php if($course->is_enrollable): ?>
                                        <span class="badge bg-success">نعم</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">لا</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.courses.show', $course)); ?>" class="btn btn-sm btn-info" title="عرض وتفاصيل"><i class="fas fa-eye"></i></a>
                                    <a href="<?php echo e(route('admin.courses.edit', $course)); ?>" class="btn btn-sm btn-primary" title="تعديل"><i class="fas fa-edit"></i></a>
                                    <form action="<?php echo e(route('admin.courses.destroy', $course)); ?>" method="POST" class="d-inline" onsubmit="return confirm('هل أنت متأكد من رغبتك في حذف هذا المقرر؟ سيؤدي هذا إلى حذف موارده وتعلقاته الأخرى.');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" title="حذف"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <?php echo e($courses->appends(request()->query())->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/courses/index.blade.php ENDPATH**/ ?>