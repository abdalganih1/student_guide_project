<div class="sidebar border-start">
    <h4 class="px-3">لوحة التحكم</h4>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="fas fa-tachometer-alt me-2"></i>لوحة القيادة
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.faculties.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.faculties.index')); ?>">
                <i class="fas fa-university me-2"></i>إدارة الكليات
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.specializations.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.specializations.index')); ?>">
                <i class="fas fa-sitemap me-2"></i>إدارة الاختصاصات
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.instructors.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.instructors.index')); ?>">
                <i class="fas fa-chalkboard-teacher me-2"></i>إدارة المدرسين
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.courses.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.courses.index')); ?>">
                <i class="fas fa-book-open me-2"></i>إدارة المقررات
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.projects.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.projects.index')); ?>">
                <i class="fas fa-project-diagram me-2"></i>إدارة المشاريع
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.university-facilities.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.university-facilities.index')); ?>">
                <i class="fas fa-photo-video me-2"></i>إدارة وسائط الجامعة
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.events.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.events.index')); ?>">
                <i class="fas fa-calendar-alt me-2"></i>إدارة الفعاليات
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.event-registrations.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.event-registrations.index')); ?>">
                <i class="fas fa-clipboard-check me-2"></i>طلبات تسجيل الفعاليات
            </a>
        </li>
         <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.students.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.students.index')); ?>">
                <i class="fas fa-user-graduate me-2"></i>إدارة الطلاب
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.notifications.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.notifications.index')); ?>">
                <i class="fas fa-bell me-2"></i>إدارة التنبيهات
            </a>
        </li>
        <?php if(auth()->guard('admin_web')->check()): ?> 
        <?php if(Auth::guard('admin_web')->user()->role === 'superadmin'): ?> 
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('admin.admin-users.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.admin-users.index')); ?>">
                <i class="fas fa-users-cog me-2"></i>إدارة مديري النظام
            </a>
        </li>
        <?php endif; ?>
        <li class="nav-item mt-auto">
             <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="nav-link text-danger">
                    <i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج
                </button>
            </form>
        </li>
        <?php endif; ?>
    </ul>

</div><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/partials/_sidebar.blade.php ENDPATH**/ ?>