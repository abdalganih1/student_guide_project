<?php $__env->startSection('title', 'إدارة التنبيهات'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-bell me-2"></i>إدارة التنبيهات</h1>
        <a href="<?php echo e(route('admin.notifications.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus me-1"></i> إرسال تنبيه جديد
        </a>
    </div>

    

    <div class="card">
        <div class="card-body">
            <?php if($notifications->isEmpty()): ?>
                <div class="alert alert-info text-center">لا توجد تنبيهات لعرضها حالياً.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>العنوان (عربي)</th>
                                <th>النوع</th>
                                <th>الجمهور المستهدف</th>
                                <th>تاريخ النشر</th>
                                <th>المرسل</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($notification->id); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.notifications.show', $notification)); ?>"><?php echo e(Str::limit($notification->title_ar, 50)); ?></a>
                                    <?php if($notification->title_en): ?><small class="d-block text-muted"><?php echo e(Str::limit($notification->title_en, 50)); ?></small><?php endif; ?>
                                </td>
                                <td><?php echo e($notification->type); ?></td>
                                <td>
                                    <?php if($notification->target_audience_type == 'all'): ?>
                                        الكل
                                    <?php elseif($notification->target_audience_type == 'course_specific' && $notification->relatedCourse): ?>
                                        طلاب مقرر: <a href="<?php echo e(route('admin.courses.show', $notification->relatedCourse)); ?>"><?php echo e($notification->relatedCourse->name_ar); ?></a>
                                    <?php elseif($notification->target_audience_type == 'custom_group' || $notification->target_audience_type == 'individual'): ?>
                                        مجموعة مخصصة/أفراد (<?php echo e($notification->recipients->count()); ?>)
                                    <?php else: ?>
                                        <?php echo e($notification->target_audience_type); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($notification->publish_datetime->translatedFormat('Y-m-d H:i')); ?></td>
                                <td><?php echo e($notification->sentByAdmin->username ?? '-'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.notifications.show', $notification)); ?>" class="btn btn-sm btn-info" title="عرض التفاصيل"><i class="fas fa-eye"></i></a>
                                    
                                    
                                    <form action="" method="POST" class="d-inline" onsubmit="return confirm('هل أنت متأكد من رغبتك في حذف هذا التنبيه؟');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger disabled" title="حذف"><i class="fas fa-trash"></i></button>
                                    </form>
                                    
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <?php echo e($notifications->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/notifications/index.blade.php ENDPATH**/ ?>