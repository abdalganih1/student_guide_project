<?php $__env->startSection('title', 'إدارة وسائط الجامعة'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-photo-video me-2"></i>إدارة وسائط الجامعة</h1>
        <a href="<?php echo e(route('admin.university-facilities.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus me-1"></i> إضافة وسيط جديد
        </a>
    </div>

    
    <div class="card mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.university-facilities.index')); ?>">
                <div class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label for="category_filter" class="form-label">التصنيف</label>
                        <select class="form-select form-select-sm" id="category_filter" name="category">
                            <option value="">-- كل التصنيفات --</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category); ?>" <?php echo e(request('category') == $category ? 'selected' : ''); ?>>
                                    <?php echo e($category); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="media_type_filter" class="form-label">نوع الوسيط</label>
                        <select class="form-select form-select-sm" id="media_type_filter" name="media_type">
                            <option value="">-- كل الأنواع --</option>
                            <?php $__currentLoopData = $mediaTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeKey => $typeName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($typeKey); ?>" <?php echo e(request('media_type') == $typeKey ? 'selected' : ''); ?>>
                                    <?php echo e($typeName); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="faculty_id_filter" class="form-label">الكلية</label>
                        <select class="form-select form-select-sm" id="faculty_id_filter" name="faculty_id">
                            <option value="">-- كل الكليات --</option>
                            <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($faculty->id); ?>" <?php echo e(request('faculty_id') == $faculty->id ? 'selected' : ''); ?>>
                                    <?php echo e($faculty->name_ar); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary btn-sm w-100">فلترة</button>
                    </div>
                    <div class="col-md-1">
                        <a href="<?php echo e(route('admin.university-facilities.index')); ?>" class="btn btn-secondary btn-sm w-100">إلغاء</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <?php if($mediaItems->isEmpty()): ?>
                <div class="alert alert-info text-center">لا توجد وسائط جامعية لعرضها حالياً.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>معاينة</th>
                                <th>العنوان (عربي)</th>
                                <th>النوع</th>
                                <th>التصنيف</th>
                                <th>الكلية</th>
                                <th>رفع بواسطة</th>
                                <th>تاريخ الرفع</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mediaItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td>
                                    <?php if($item->media_type == 'image' && $item->file_url): ?>
                                        <a href="<?php echo e(Storage::url($item->file_url)); ?>" target="_blank">
                                            <img src="<?php echo e(Storage::url($item->file_url)); ?>" alt="<?php echo e($item->title_ar ?: 'صورة'); ?>" class="img-thumbnail" style="width: 60px; height: 40px; object-fit: cover;">
                                        </a>
                                    <?php elseif($item->media_type == 'video' && $item->file_url): ?>
                                        <a href="<?php echo e(Storage::url($item->file_url)); ?>" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-video"></i> فيديو</a>
                                    <?php elseif($item->media_type == 'document' && $item->file_url): ?>
                                        <a href="<?php echo e(Storage::url($item->file_url)); ?>" target="_blank" class="btn btn-sm btn-outline-secondary"><i class="fas fa-file-alt"></i> مستند</a>
                                    <?php else: ?>
                                        <i class="fas fa-file fa-2x text-secondary"></i>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->title_ar ?: (Str::limit(basename($item->file_url), 30) ?: '-')); ?></td>
                                <td><?php echo e($mediaTypes[$item->media_type] ?? $item->media_type); ?></td>
                                <td><?php echo e($item->category ?: '-'); ?></td>
                                <td><?php echo e($item->faculty->name_ar ?? '-'); ?></td>
                                <td><?php echo e($item->uploadedByAdmin->username ?? '-'); ?></td>
                                <td><?php echo e($item->created_at->translatedFormat('Y-m-d')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.university-facilities.show', $item)); ?>" class="btn btn-sm btn-info" title="عرض"><i class="fas fa-eye"></i></a>
                                    <a href="<?php echo e(route('admin.university-facilities.edit', $item)); ?>" class="btn btn-sm btn-primary" title="تعديل"><i class="fas fa-edit"></i></a>
                                    <form action="<?php echo e(route('admin.university-facilities.destroy', $item)); ?>" method="POST" class="d-inline" onsubmit="return confirm('هل أنت متأكد من رغبتك في حذف هذا الوسيط؟');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" title="حذف"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <?php echo e($mediaItems->appends(request()->query())->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/university_facilities/index.blade.php ENDPATH**/ ?>