<?php $__env->startSection('title', 'تفاصيل الطالب: ' . $student->full_name_ar); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1><i class="fas fa-user-graduate me-2"></i>تفاصيل الطالب: <?php echo e($student->full_name_ar); ?></h1>
        <div>
            <a href="<?php echo e(route('admin.students.edit', $student)); ?>" class="btn btn-primary"><i class="fas fa-edit me-1"></i> تعديل</a>
            <a href="<?php echo e(route('admin.students.index')); ?>" class="btn btn-secondary">العودة إلى القائمة</a>
        </div>
    </div>

    <div class="card">
        <div class="row g-0">
            <div class="col-md-3 text-center p-3 border-end">
                <?php if($student->profile_picture_url): ?>
                    <img src="<?php echo e(Storage::url($student->profile_picture_url)); ?>" alt="<?php echo e($student->full_name_ar); ?>" class="img-fluid rounded-circle mb-2" style="width: 150px; height: 150px; object-fit: cover;">
                <?php else: ?>
                    <i class="fas fa-user fa-5x text-secondary mb-2"></i>
                <?php endif; ?>
                <h5 class="card-title"><?php echo e($student->full_name_ar); ?></h5>
                <p class="card-text"><small class="text-muted"><?php echo e($student->student_university_id); ?></small></p>
                <?php if($student->is_active): ?>
                    <span class="badge bg-success">نشط</span>
                <?php else: ?>
                    <span class="badge bg-danger">غير نشط</span>
                <?php endif; ?>
            </div>
            <div class="col-md-9">
                <div class="card-body">
                    <h5 class="card-title mb-3">معلومات الطالب</h5>
                    <dl class="row">
                        <dt class="col-sm-4">الاسم (عربي):</dt>
                        <dd class="col-sm-8"><?php echo e($student->full_name_ar); ?></dd>

                        <dt class="col-sm-4">الاسم (إنجليزي):</dt>
                        <dd class="col-sm-8"><?php echo e($student->full_name_en ?: '-'); ?></dd>

                        <dt class="col-sm-4">الرقم الجامعي:</dt>
                        <dd class="col-sm-8"><?php echo e($student->student_university_id); ?></dd>

                        <dt class="col-sm-4">البريد الإلكتروني:</dt>
                        <dd class="col-sm-8"><?php echo e($student->email); ?></dd>

                        <dt class="col-sm-4">الاختصاص:</dt>
                        <dd class="col-sm-8"><?php echo e($student->specialization->name_ar ?? 'غير محدد'); ?></dd>

                        <dt class="col-sm-4">سنة الالتحاق:</dt>
                        <dd class="col-sm-8"><?php echo e($student->enrollment_year ?: '-'); ?></dd>

                        <dt class="col-sm-4">آخر إجراء إداري بواسطة:</dt>
                        <dd class="col-sm-8"><?php echo e($student->adminActionBy->name_ar ?? '-'); ?> <?php if($student->admin_action_at): ?> (في: <?php echo e($student->admin_action_at->translatedFormat('Y-m-d')); ?>) <?php endif; ?></dd>

                        <?php if($student->admin_action_notes): ?>
                        <dt class="col-sm-4">ملاحظات إدارية:</dt>
                        <dd class="col-sm-8"><?php echo e($student->admin_action_notes); ?></dd>
                        <?php endif; ?>

                        <dt class="col-sm-4">تاريخ الإضافة:</dt>
                        <dd class="col-sm-8"><?php echo e($student->created_at->translatedFormat('Y-m-d H:i')); ?></dd>
                    </dl>
                </div>
            </div>
        </div>
    </div>
   <div class="card mt-4">
        <div class="card-header">
            <h4><i class="fas fa-book-open me-2"></i>المقررات المسجل بها الطالب (<?php echo e($student->courseEnrollments->count()); ?>)</h4>
        </div>
        <div class="card-body">
            <?php if($student->courseEnrollments->isEmpty()): ?>
                <p class="text-muted">لم يسجل الطالب في أي مقررات حالياً.</p>
            <?php else: ?>
                <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $student->courseEnrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php if($enrollment->course): ?> 
                                <a href="<?php echo e(route('admin.courses.show', $enrollment->course)); ?>"><?php echo e($enrollment->course->name_ar ?? 'مقرر غير معروف'); ?></a>
                                (<?php echo e($enrollment->course->code ?? '-'); ?>) - الفصل: <?php echo e($enrollment->semester_enrolled); ?>

                                <br>
                                <small>الحالة: <?php echo e($enrollment->status); ?> <?php if($enrollment->grade): ?> | الدرجة: <?php echo e($enrollment->grade); ?> <?php endif; ?></small>
                            <?php else: ?>
                                <span class="text-danger">مقرر محذوف (ID المقرر في التسجيل: <?php echo e($enrollment->course_id); ?>)</span>
                                - الفصل: <?php echo e($enrollment->semester_enrolled); ?>

                                <br>
                                <small>الحالة: <?php echo e($enrollment->status); ?> <?php if($enrollment->grade): ?> | الدرجة: <?php echo e($enrollment->grade); ?> <?php endif; ?></small>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h4><i class="fas fa-calendar-check me-2"></i>الفعاليات المسجل بها الطالب (<?php echo e($student->eventRegistrations->count()); ?>)</h4>
        </div>
        <div class="card-body">
            <?php if($student->eventRegistrations->isEmpty()): ?>
                <p class="text-muted">لم يسجل الطالب في أي فعاليات حالياً.</p>
            <?php else: ?>
                 <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $student->eventRegistrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php if($registration->event): ?> 
                                <a href="<?php echo e(route('admin.events.show', $registration->event)); ?>"><?php echo e($registration->event->title_ar ?? 'فعالية غير معروفة'); ?></a>
                                 - <small>حالة التسجيل: <?php echo e($registration->status); ?></small>
                            <?php else: ?>
                                <span class="text-danger">فعالية محذوفة (ID الفعالية في التسجيل: <?php echo e($registration->event_id); ?>)</span>
                                - <small>حالة التسجيل: <?php echo e($registration->status); ?></small>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/students/show.blade.php ENDPATH**/ ?>