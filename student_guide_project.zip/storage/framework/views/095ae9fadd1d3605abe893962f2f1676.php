<nav class="navbar navbar-expand-lg navbar-light bg-light mb-4 border-bottom">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <?php if(auth()->guard('admin_web')->check()): ?>
<span class="navbar-text">
    مرحباً، <?php echo e(Auth::guard('admin_web')->user()->name_ar ?: Auth::guard('admin_web')->user()->username); ?>

</span>
<?php endif; ?>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/partials/_navbar.blade.php ENDPATH**/ ?>