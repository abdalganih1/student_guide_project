<?php $__env->startSection('title', 'تفاصيل مشروع التخرج: ' . Str::limit($project->title_ar, 30)); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1><i class="fas fa-eye me-2"></i>تفاصيل مشروع: <?php echo e($project->title_ar); ?></h1>
        <div>
            <a href="<?php echo e(route('admin.projects.edit', $project)); ?>" class="btn btn-primary"><i class="fas fa-edit me-1"></i> تعديل</a>
            <a href="<?php echo e(route('admin.projects.index')); ?>" class="btn btn-secondary">العودة إلى القائمة</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-8">
                    <h3><?php echo e($project->title_ar); ?></h3>
                    <?php if($project->title_en): ?>
                        <h5 class="text-muted"><?php echo e($project->title_en); ?></h5>
                    <?php endif; ?>
                </div>
                <div class="col-md-4 text-md-end">
                    <p class="mb-0"><strong>السنة:</strong> <?php echo e($project->year); ?></p>
                    <p class="mb-0"><strong>الفصل:</strong> <?php echo e($project->semester); ?></p>
                </div>
            </div>
            <hr>
            <dl class="row">
                <dt class="col-sm-3">الاختصاص:</dt>
                <dd class="col-sm-9"><a href="<?php echo e(route('admin.specializations.show', $project->specialization)); ?>"><?php echo e($project->specialization->name_ar ?? 'غير محدد'); ?></a></dd>

                <dt class="col-sm-3">المشرف:</dt>
                <dd class="col-sm-9"><?php echo e($project->supervisor ? $project->supervisor->name_ar : 'لا يوجد'); ?></dd>

                <dt class="col-sm-3">أسماء الطلاب:</dt>
                <dd class="col-sm-9"><?php echo e($project->student_names ?: '-'); ?></dd>

                <dt class="col-sm-3">نوع المشروع:</dt>
                <dd class="col-sm-9"><?php echo e($project->project_type ?: '-'); ?></dd>

                <dt class="col-sm-3">الكلمات المفتاحية:</dt>
                <dd class="col-sm-9"><?php echo e($project->keywords ?: '-'); ?></dd>
            </dl>

            <?php if($project->abstract_ar): ?>
            <hr>
            <h5>الملخص (عربي):</h5>
            <div class="bg-light p-3 rounded" style="white-space: pre-wrap;"><?php echo e($project->abstract_ar); ?></div>
            <?php endif; ?>

            <?php if($project->abstract_en): ?>
            <hr>
            <h5>الملخص (إنجليزي):</h5>
            <div class="bg-light p-3 rounded" style="white-space: pre-wrap;"><?php echo e($project->abstract_en); ?></div>
            <?php endif; ?>
            <hr>
            <small class="text-muted">
                تم إنشاؤه بواسطة: <?php echo e($project->createdByAdmin->name_ar ?? 'غير معروف'); ?> (<?php echo e($project->createdByAdmin->username ?? ''); ?>) في <?php echo e($project->created_at->translatedFormat('Y-m-d')); ?> <br>
                آخر تحديث بواسطة: <?php echo e($project->lastUpdatedByAdmin->name_ar ?? 'غير معروف'); ?> (<?php echo e($project->lastUpdatedByAdmin->username ?? ''); ?>) في <?php echo e($project->updated_at->translatedFormat('Y-m-d')); ?>

            </small>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/projects/show.blade.php ENDPATH**/ ?>