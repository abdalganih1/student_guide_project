

<?php $__env->startSection('title', 'تفاصيل مدير النظام: ' . $adminUser->username); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1><i class="fas fa-user-shield me-2"></i>تفاصيل مدير النظام: <?php echo e($adminUser->username); ?></h1>
        <div>
            <?php if(Auth::guard('admin_web')->user()->role === 'superadmin'): ?>
                <a href="<?php echo e(route('admin.admin-users.edit', $adminUser)); ?>" class="btn btn-primary"><i class="fas fa-edit me-1"></i> تعديل</a>
            <?php endif; ?>
            <a href="<?php echo e(route('admin.admin-users.index')); ?>" class="btn btn-secondary">العودة إلى القائمة</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <dl class="row">
                <dt class="col-sm-3">اسم المستخدم:</dt>
                <dd class="col-sm-9"><?php echo e($adminUser->username); ?></dd>

                <dt class="col-sm-3">الاسم (عربي):</dt>
                <dd class="col-sm-9"><?php echo e($adminUser->name_ar); ?></dd>

                <dt class="col-sm-3">الاسم (إنجليزي):</dt>
                <dd class="col-sm-9"><?php echo e($adminUser->name_en ?: '-'); ?></dd>

                <dt class="col-sm-3">البريد الإلكتروني:</dt>
                <dd class="col-sm-9"><?php echo e($adminUser->email); ?></dd>

                <dt class="col-sm-3">الدور:</dt>
                <dd class="col-sm-9">
                    <?php if($adminUser->role == 'superadmin'): ?> مدير عام
                    <?php elseif($adminUser->role == 'content_manager'): ?> مدير محتوى
                    <?php else: ?> <?php echo e($adminUser->role); ?>

                    <?php endif; ?>
                </dd>

                <dt class="col-sm-3">الحالة:</dt>
                <dd class="col-sm-9"><?php echo e($adminUser->is_active ? 'نشط' : 'غير نشط'); ?></dd>

                <dt class="col-sm-3">تاريخ الإضافة:</dt>
                <dd class="col-sm-9"><?php echo e($adminUser->created_at->translatedFormat('l, d F Y H:i')); ?></dd>

                <dt class="col-sm-3">آخر تحديث:</dt>
                <dd class="col-sm-9"><?php echo e($adminUser->updated_at->translatedFormat('l, d F Y H:i')); ?></dd>
            </dl>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/admin_users/show.blade.php ENDPATH**/ ?>