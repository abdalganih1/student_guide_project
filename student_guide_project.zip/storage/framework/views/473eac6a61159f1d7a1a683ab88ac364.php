<?php $__env->startSection('title', 'تفاصيل التنبيه: ' . Str::limit($notification->title_ar, 30)); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1><i class="fas fa-info-circle me-2"></i>تفاصيل التنبيه</h1>
        <a href="<?php echo e(route('admin.notifications.index')); ?>" class="btn btn-secondary">العودة إلى القائمة</a>
    </div>

    <div class="card">
        <div class="card-header">
            <h5><?php echo e($notification->title_ar); ?></h5>
            <?php if($notification->title_en): ?> <p class="text-muted mb-0"><?php echo e($notification->title_en); ?></p> <?php endif; ?>
        </div>
        <div class="card-body">
            <dl class="row">
                <dt class="col-sm-3">نص التنبيه (عربي):</dt>
                <dd class="col-sm-9" style="white-space: pre-wrap;"><?php echo e($notification->body_ar); ?></dd>

                <?php if($notification->body_en): ?>
                <dt class="col-sm-3">نص التنبيه (إنجليزي):</dt>
                <dd class="col-sm-9" style="white-space: pre-wrap;"><?php echo e($notification->body_en); ?></dd>
                <?php endif; ?>

                <dt class="col-sm-3">النوع:</dt>
                <dd class="col-sm-9"><?php echo e($notification->type); ?></dd>

                <dt class="col-sm-3">المرسل:</dt>
                <dd class="col-sm-9"><?php echo e($notification->sentByAdmin->username ?? 'غير معروف'); ?></dd>

                <dt class="col-sm-3">تاريخ النشر:</dt>
                <dd class="col-sm-9"><?php echo e($notification->publish_datetime->translatedFormat('l, d F Y - H:i A')); ?></dd>

                <?php if($notification->expiry_datetime): ?>
                <dt class="col-sm-3">تاريخ انتهاء الصلاحية:</dt>
                <dd class="col-sm-9"><?php echo e($notification->expiry_datetime->translatedFormat('l, d F Y - H:i A')); ?></dd>
                <?php endif; ?>

                <dt class="col-sm-3">الجمهور المستهدف:</dt>
                <dd class="col-sm-9">
                    <?php if($notification->target_audience_type == 'all'): ?>
                        جميع الطلاب
                    <?php elseif($notification->target_audience_type == 'course_specific' && $notification->relatedCourse): ?>
                        طلاب مقرر: <a href="<?php echo e(route('admin.courses.show', $notification->relatedCourse)); ?>"><?php echo e($notification->relatedCourse->name_ar); ?></a>
                    <?php elseif($notification->target_audience_type == 'custom_group' || $notification->target_audience_type == 'individual'): ?>
                        مجموعة مخصصة / أفراد (<?php echo e($notification->recipients->count()); ?> طالب)
                    <?php else: ?>
                        <?php echo e($notification->target_audience_type); ?>

                    <?php endif; ?>
                </dd>

                <?php if($notification->relatedCourse): ?>
                <dt class="col-sm-3">المقرر المرتبط:</dt>
                <dd class="col-sm-9"><a href="<?php echo e(route('admin.courses.show', $notification->relatedCourse)); ?>"><?php echo e($notification->relatedCourse->name_ar); ?></a></dd>
                <?php endif; ?>

                <?php if($notification->relatedEvent): ?>
                <dt class="col-sm-3">الفعالية المرتبطة:</dt>
                <dd class="col-sm-9"><a href="<?php echo e(route('admin.events.show', $notification->relatedEvent)); ?>"><?php echo e($notification->relatedEvent->title_ar); ?></a></dd>
                <?php endif; ?>
            </dl>

            <?php if($notification->target_audience_type == 'custom_group' || $notification->target_audience_type == 'individual'): ?>
                <hr>
                <h5>الطلاب المستلمون:</h5>
                <?php if($notification->recipients->isEmpty()): ?>
                    <p class="text-muted">لم يتم تحديد طلاب مستلمين بشكل فردي لهذا التنبيه.</p>
                <?php else: ?>
                    <ul>
                        <?php $__currentLoopData = $notification->recipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('admin.students.show', $student)); ?>"><?php echo e($student->full_name_ar); ?></a> (<?php echo e($student->student_university_id); ?>)</li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="card-footer text-muted">
            تم الإنشاء في: <?php echo e($notification->created_at->translatedFormat('Y-m-d H:i')); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/notifications/show.blade.php ENDPATH**/ ?>