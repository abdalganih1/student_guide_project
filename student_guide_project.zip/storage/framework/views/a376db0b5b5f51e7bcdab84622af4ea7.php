<?php $__env->startSection('title', 'تفاصيل المدرس: ' . $instructor->name_ar); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1><i class="fas fa-user-tie me-2"></i>تفاصيل المدرس: <?php echo e($instructor->name_ar); ?></h1>
        <div>
            <a href="<?php echo e(route('admin.instructors.edit', $instructor)); ?>" class="btn btn-primary"><i class="fas fa-edit me-1"></i> تعديل</a>
            <a href="<?php echo e(route('admin.instructors.index')); ?>" class="btn btn-secondary">العودة إلى القائمة</a>
        </div>
    </div>

    <div class="card">
        <div class="row g-0">
            <div class="col-md-3 text-center p-3 border-end">
                <?php if($instructor->profile_picture_url): ?>
                    <img src="<?php echo e(Storage::url($instructor->profile_picture_url)); ?>" alt="<?php echo e($instructor->name_ar); ?>" class="img-fluid rounded-circle mb-2" style="width: 150px; height: 150px; object-fit: cover;">
                <?php else: ?>
                    <i class="fas fa-user-tie fa-5x text-secondary mb-2"></i>
                <?php endif; ?>
                <h5 class="card-title"><?php echo e($instructor->name_ar); ?></h5>
                <p class="card-text"><small class="text-muted"><?php echo e($instructor->title ?: 'مدرس'); ?></small></p>
                <?php if($instructor->is_active): ?>
                    <span class="badge bg-success">نشط</span>
                <?php else: ?>
                    <span class="badge bg-danger">غير نشط</span>
                <?php endif; ?>
            </div>
            <div class="col-md-9">
                <div class="card-body">
                    <h5 class="card-title mb-3">معلومات المدرس</h5>
                    <div class="row">
                        <div class="col-sm-6">
                            <p><strong>الاسم (عربي):</strong> <?php echo e($instructor->name_ar); ?></p>
                            <p><strong>البريد الإلكتروني:</strong> <?php echo e($instructor->email ?: '-'); ?></p>
                            <p><strong>الكلية:</strong> <?php echo e($instructor->faculty->name_ar ?? 'غير محدد'); ?></p>
                        </div>
                        <div class="col-sm-6">
                            <p><strong>الاسم (إنجليزي):</strong> <?php echo e($instructor->name_en ?: '-'); ?></p>
                            <p><strong>موقع المكتب:</strong> <?php echo e($instructor->office_location ?: '-'); ?></p>
                            <p><strong>تاريخ الإضافة:</strong> <?php echo e($instructor->created_at->translatedFormat('Y-m-d')); ?></p>
                        </div>
                    </div>
                    <?php if($instructor->bio): ?>
                    <hr>
                    <h6>نبذة تعريفية:</h6>
                    <p><?php echo e($instructor->bio); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    
    
    <div class="card mt-4">
        <div class="card-header">
            <h4><i class="fas fa-book me-2"></i>المقررات</h4>
        </div>
        <div class="card-body">
            <p class="text-muted">لا يتم ربط المدرسين بالمقررات بشكل مباشر في هذا النظام حالياً من خلال ملف المدرس الشخصي.</p>
            
            
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h4><i class="fas fa-graduation-cap me-2"></i>المشاريع التي يشرف عليها (<?php echo e($instructor->supervisedProjects->count()); ?>)</h4>
        </div>
        <div class="card-body">
             <?php if($instructor->supervisedProjects->isEmpty()): ?>
                <p class="text-muted">لا يوجد مشاريع يشرف عليها هذا المدرس حالياً.</p>
            <?php else: ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $instructor->supervisedProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <a href="<?php echo e(route('admin.projects.show', $project)); ?>"><?php echo e($project->title_ar); ?></a> (<?php echo e($project->year); ?>)
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/instructors/show.blade.php ENDPATH**/ ?>