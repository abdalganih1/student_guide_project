<?php $__env->startSection('title', 'تفاصيل الفعالية: ' . $event->title_ar); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1><i class="fas fa-calendar-check me-2"></i>تفاصيل الفعالية: <?php echo e($event->title_ar); ?></h1>
        <div>
            <a href="<?php echo e(route('admin.events.edit', $event)); ?>" class="btn btn-primary"><i class="fas fa-edit me-1"></i> تعديل</a>
            <a href="<?php echo e(route('admin.event-registrations.index', ['event_id' => $event->id])); ?>" class="btn btn-warning"><i class="fas fa-users me-1"></i> عرض طلبات التسجيل (<?php echo e($event->registeredStudents->count()); ?>)</a>
            <a href="<?php echo e(route('admin.events.index')); ?>" class="btn btn-secondary">العودة إلى القائمة</a>
        </div>
    </div>

    <div class="card">
        <div class="row g-0">
            <?php if($event->main_image_url): ?>
            <div class="col-md-4 text-center p-3 border-end">
                <img src="<?php echo e(Storage::url($event->main_image_url)); ?>" alt="<?php echo e($event->title_ar); ?>" class="img-fluid rounded" style="max-height: 300px; object-fit: contain;">
            </div>
            <?php endif; ?>
            <div class="<?php echo e($event->main_image_url ? 'col-md-8' : 'col-md-12'); ?>">
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($event->title_ar); ?></h3>
                    <?php if($event->title_en): ?>
                        <h5 class="text-muted"><?php echo e($event->title_en); ?></h5>
                    <?php endif; ?>
                    <hr>
                    <dl class="row">
                        <dt class="col-sm-4">تاريخ ووقت البدء:</dt>
                        <dd class="col-sm-8"><?php echo e($event->event_start_datetime->translatedFormat('l, d F Y - H:i A')); ?></dd>

                        <?php if($event->event_end_datetime): ?>
                        <dt class="col-sm-4">تاريخ ووقت الانتهاء:</dt>
                        <dd class="col-sm-8"><?php echo e($event->event_end_datetime->translatedFormat('l, d F Y - H:i A')); ?></dd>
                        <?php endif; ?>

                        <dt class="col-sm-4">الموقع:</dt>
                        <dd class="col-sm-8"><?php echo e($event->location_text ?: '-'); ?></dd>

                        <dt class="col-sm-4">التصنيف:</dt>
                        <dd class="col-sm-8"><?php echo e($event->category ?: '-'); ?></dd>

                        <dt class="col-sm-4">الحالة:</dt>
                        <dd class="col-sm-8">
                            <span class="badge bg-<?php echo e($event->status == 'scheduled' ? 'info' : ($event->status == 'ongoing' ? 'primary' : ($event->status == 'completed' ? 'success' : ($event->status == 'cancelled' ? 'danger' : 'secondary')))); ?>">
                                <?php echo e($statuses[$event->status] ?? $event->status); ?>

                            </span>
                        </dd>

                        <dt class="col-sm-4">يتطلب تسجيل:</dt>
                        <dd class="col-sm-8"><?php echo e($event->requires_registration ? 'نعم' : 'لا'); ?></dd>

                        <?php if($event->requires_registration): ?>
                        <dt class="col-sm-4">الموعد النهائي للتسجيل:</dt>
                        <dd class="col-sm-8"><?php echo e($event->registration_deadline ? $event->registration_deadline->translatedFormat('l, d F Y - H:i A') : '-'); ?></dd>
                        <?php endif; ?>

                        <dt class="col-sm-4">الحد الأقصى للحضور:</dt>
                        <dd class="col-sm-8"><?php echo e($event->max_attendees ?: 'غير محدد'); ?></dd>

                        <dt class="col-sm-4">الجهة المنظمة:</dt>
                        <dd class="col-sm-8"><?php echo e($event->organizer_info ?: ($event->organizingFaculty->name_ar ?? '-')); ?></dd>

                        <?php if($event->organizingFaculty): ?>
                        <dt class="col-sm-4">الكلية المنظمة:</dt>
                        <dd class="col-sm-8"><a href="<?php echo e(route('admin.faculties.show', $event->organizingFaculty)); ?>"><?php echo e($event->organizingFaculty->name_ar); ?></a></dd>
                        <?php endif; ?>
                    </dl>
                    <hr>
                    <h5>الوصف (عربي):</h5>
                    <div style="white-space: pre-wrap;"><?php echo e($event->description_ar); ?></div>

                    <?php if($event->description_en): ?>
                    <hr>
                    <h5>الوصف (إنجليزي):</h5>
                    <div style="white-space: pre-wrap;"><?php echo e($event->description_en); ?></div>
                    <?php endif; ?>
                    <hr>
                     <small class="text-muted">
                        تم إنشاؤه بواسطة: <?php echo e($event->createdByAdmin->name_ar ?? 'غير معروف'); ?> في <?php echo e($event->created_at->translatedFormat('Y-m-d')); ?> <br>
                        آخر تحديث بواسطة: <?php echo e($event->lastUpdatedByAdmin->name_ar ?? 'غير معروف'); ?> في <?php echo e($event->updated_at->translatedFormat('Y-m-d')); ?>

                    </small>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card mt-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-users me-2"></i>الطلاب المسجلون (<?php echo e($event->registeredStudents->count()); ?>)</h5>
            <a href="<?php echo e(route('admin.event-registrations.index', ['event_id' => $event->id])); ?>" class="btn btn-sm btn-outline-primary">إدارة التسجيلات</a>
        </div>
         <div class="card-body">
            <?php if($event->registeredStudents->isEmpty()): ?>
                <p class="text-muted">لا يوجد طلاب مسجلون في هذه الفعالية حالياً.</p>
            <?php else: ?>
                <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $event->registeredStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                            <?php if($registration->student): ?>
                                <a href="<?php echo e(route('admin.students.show', $registration->student)); ?>"><?php echo e($registration->student->full_name_ar); ?></a>
                                <small class="text-muted">(<?php echo e($registration->student->student_university_id); ?>)</small>
                            <?php else: ?>
                                <span class="text-danger">طالب محذوف (ID: <?php echo e($registration->student_id); ?>)</span>
                            <?php endif; ?>
                            </div>
                            <div>
                                <span class="badge bg-<?php echo e($registration->status == 'registered' || $registration->status == 'approved' ? 'success' : ($registration->status == 'pending_approval' ? 'warning text-dark' : 'danger')); ?>">
                                    <?php if($registration->status == 'registered' || $registration->status == 'approved'): ?> تم التسجيل
                                    <?php elseif($registration->status == 'pending_approval'): ?> قيد المراجعة
                                    <?php elseif($registration->status == 'rejected'): ?> مرفوض
                                    <?php elseif($registration->status == 'waitlisted'): ?> قائمة انتظار
                                    <?php elseif($registration->status == 'cancelled_by_student'): ?> ملغى من الطالب
                                    <?php else: ?> <?php echo e($registration->status); ?>

                                    <?php endif; ?>
                                </span>
                                <?php if($registration->attended): ?>
                                    <span class="badge bg-info">حضر</span>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/events/show.blade.php ENDPATH**/ ?>