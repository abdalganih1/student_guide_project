<div>
    <!-- Well begun is half done. - Aristotle -->
</div>
<?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/specializations/edit.blade.php ENDPATH**/ ?>