

<?php $__env->startSection('title', 'تفاصيل المقرر: ' . $course->name_ar); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function confirmResourceDeletion(formId) {
        if (confirm('هل أنت متأكد من رغبتك في حذف هذا المورد؟')) {
            document.getElementById(formId).submit();
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1><i class="fas fa-book-reader me-2"></i>تفاصيل المقرر: <?php echo e($course->name_ar); ?> (<?php echo e($course->code); ?>)</h1>
        <div>
            <a href="<?php echo e(route('admin.courses.edit', $course)); ?>" class="btn btn-primary"><i class="fas fa-edit me-1"></i> تعديل المقرر</a>
            <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn btn-secondary">العودة إلى القائمة</a>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">معلومات المقرر</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>الاسم (عربي):</strong> <?php echo e($course->name_ar); ?></p>
                    <p><strong>الاسم (إنجليزي):</strong> <?php echo e($course->name_en ?: '-'); ?></p>
                    <p><strong>رمز المقرر:</strong> <?php echo e($course->code); ?></p>
                    <p><strong>الاختصاص:</strong> <a href="<?php echo e(route('admin.specializations.show', $course->specialization)); ?>"><?php echo e($course->specialization->name_ar ?? 'غير محدد'); ?></a></p>
                </div>
                <div class="col-md-6">
                    <p><strong>معلومات الفصل:</strong> <?php echo e($course->semester_display_info); ?></p>
                    <p><strong>مستوى السنة:</strong> <?php echo e($course->year_level ?: '-'); ?></p>
                    <p><strong>الساعات المعتمدة:</strong> <?php echo e($course->credits ?: '-'); ?></p>
                    <p><strong>متاح للتسجيل:</strong> <?php echo e($course->is_enrollable ? 'نعم' : 'لا'); ?> <?php if($course->enrollment_capacity): ?> (السعة: <?php echo e($course->enrollment_capacity); ?>) <?php endif; ?></p>
                </div>
            </div>
            <?php if($course->description_ar): ?>
            <hr>
            <h6>الوصف (عربي):</h6>
            <p><?php echo nl2br(e($course->description_ar)); ?></p>
            <?php endif; ?>
            <?php if($course->description_en): ?>
            <hr>
            <h6>الوصف (إنجليزي):</h6>
            <p><?php echo nl2br(e($course->description_en)); ?></p>
            <?php endif; ?>
            <hr>
            <small class="text-muted">
                تم إنشاؤه بواسطة: <?php echo e($course->createdByAdmin->name_ar ?? 'غير معروف'); ?> في <?php echo e($course->created_at->translatedFormat('Y-m-d')); ?> <br>
                آخر تحديث بواسطة: <?php echo e($course->lastUpdatedByAdmin->name_ar ?? 'غير معروف'); ?> في <?php echo e($course->updated_at->translatedFormat('Y-m-d')); ?>

            </small>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-folder-open me-2"></i>موارد المقرر (<?php echo e($course->resources->count()); ?>)</h5>
        </div>
        <div class="card-body">
            <?php if($course->resources->isEmpty()): ?>
                <p class="text-muted">لا توجد موارد مضافة لهذا المقرر حالياً.</p>
            <?php else: ?>
                <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $course->resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <a href="<?php echo e($resource->url); ?>" target="_blank"><?php echo e($resource->title_ar); ?></a> (<?php echo e($resource->type); ?>)
                            <small class="d-block text-muted"><?php echo e($resource->description ?: ''); ?> - مضاف في: <?php echo e($resource->semester_relevance ?: 'غير محدد'); ?></small>
                        </div>
                        <form id="delete-resource-<?php echo e($resource->id); ?>" action="<?php echo e(route('admin.courses.resources.remove', [$course, $resource])); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="button" onclick="confirmResourceDeletion('delete-resource-<?php echo e($resource->id); ?>')" class="btn btn-sm btn-outline-danger" title="حذف المورد"><i class="fas fa-trash"></i></button>
                        </form>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <hr>
            <h6>إضافة مورد جديد:</h6>
            <form action="<?php echo e(route('admin.courses.resources.add', $course)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <input type="text" name="title_ar" class="form-control form-control-sm <?php $__errorArgs = ['title_ar', 'addResourceForm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="العنوان (عربي) *" value="<?php echo e(old('title_ar')); ?>" required>
                        <?php $__errorArgs = ['title_ar', 'addResourceForm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <input type="text" name="title_en" class="form-control form-control-sm <?php $__errorArgs = ['title_en', 'addResourceForm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="العنوان (إنجليزي)" value="<?php echo e(old('title_en')); ?>">
                        <?php $__errorArgs = ['title_en', 'addResourceForm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-12">
                        <input type="url" name="url" class="form-control form-control-sm <?php $__errorArgs = ['url', 'addResourceForm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="رابط المورد *" value="<?php echo e(old('url')); ?>" required>
                         <?php $__errorArgs = ['url', 'addResourceForm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                     <div class="col-md-4">
                        <input type="text" name="type" class="form-control form-control-sm <?php $__errorArgs = ['type', 'addResourceForm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="نوع المورد (lecture_pdf) *" value="<?php echo e(old('type')); ?>" required>
                        <?php $__errorArgs = ['type', 'addResourceForm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4">
                        <input type="text" name="semester_relevance" class="form-control form-control-sm" placeholder="الفصل الدراسي للمورد" value="<?php echo e(old('semester_relevance')); ?>">
                    </div>
                    <div class="col-md-12">
                        <textarea name="description" class="form-control form-control-sm" placeholder="وصف قصير (اختياري)" rows="2"><?php echo e(old('description')); ?></textarea>
                    </div>
                    <div class="col-md-4">
                         <button type="submit" class="btn btn-sm btn-success"><i class="fas fa-plus me-1"></i> إضافة المورد</button>
                    </div>
                </div>
            </form>
             <?php if($errors->hasBag('addResourceForm')): ?> 
                <div class="alert alert-danger mt-3">
                    <h6>أخطاء في نموذج إضافة المورد:</h6>
                    <ul>
                        <?php $__currentLoopData = $errors->getBag('addResourceForm')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>

    

    
    <div class="card mt-4">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-users me-2"></i>الطلاب المسجلون في المقرر (<?php echo e($course->enrolledStudents->count()); ?>)</h5>
        </div>
        <div class="card-body">
            <?php if($course->enrolledStudents->isEmpty()): ?>
                <p class="text-muted">لا يوجد طلاب مسجلون في هذا المقرر حالياً.</p>
            <?php else: ?>
                <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $course->enrolledStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentEnrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php if($studentEnrollment->student): ?> 
                                <a href="<?php echo e(route('admin.students.show', $studentEnrollment->student)); ?>"><?php echo e($studentEnrollment->student->full_name_ar ?? 'طالب غير معروف'); ?></a>
                                - الحالة: <?php echo e($studentEnrollment->status); ?>

                                <?php if($studentEnrollment->grade): ?> - الدرجة: <?php echo e($studentEnrollment->grade); ?> <?php endif; ?>
                                (مسجل في: <?php echo e($studentEnrollment->semester_enrolled); ?>)
                            <?php else: ?>
                                <span class="text-danger">طالب محذوف (ID: <?php echo e($studentEnrollment->student_id); ?>)</span>
                                - الحالة: <?php echo e($studentEnrollment->status); ?>

                                <?php if($studentEnrollment->grade): ?> - الدرجة: <?php echo e($studentEnrollment->grade); ?> <?php endif; ?>
                                (مسجل في: <?php echo e($studentEnrollment->semester_enrolled); ?>)
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/courses/show.blade.php ENDPATH**/ ?>