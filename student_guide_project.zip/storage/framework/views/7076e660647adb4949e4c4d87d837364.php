<?php $__env->startSection('title', 'إدارة المدرسين'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-chalkboard-teacher me-2"></i>إدارة المدرسين</h1>
        <a href="<?php echo e(route('admin.instructors.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus me-1"></i> إضافة مدرس جديد
        </a>
    </div>

    
    <div class="card mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.instructors.index')); ?>">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label for="faculty_id_filter" class="form-label">فلترة حسب الكلية</label>
                        <select class="form-select" id="faculty_id_filter" name="faculty_id">
                            <option value="">-- كل الكليات --</option>
                            <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($faculty->id); ?>" <?php echo e(request('faculty_id') == $faculty->id ? 'selected' : ''); ?>>
                                    <?php echo e($faculty->name_ar); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">فلترة</button>
                    </div>
                    <div class="col-md-2">
                        <a href="<?php echo e(route('admin.instructors.index')); ?>" class="btn btn-secondary w-100">إعادة تعيين</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <?php if($instructors->isEmpty()): ?>
                <div class="alert alert-info text-center">لا يوجد مدرسون لعرضهم حالياً.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>الصورة</th>
                                <th>الاسم (عربي)</th>
                                <th>الاسم (إنجليزي)</th>
                                <th>اللقب</th>
                                <th>البريد الإلكتروني</th>
                                <th>الكلية</th>
                                <th>الحالة</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($instructor->id); ?></td>
                                <td>
                                    <?php if($instructor->profile_picture_url): ?>
                                        <img src="<?php echo e(Storage::url($instructor->profile_picture_url)); ?>" alt="<?php echo e($instructor->name_ar); ?>" class="img-thumbnail" style="width: 50px; height: 50px; object-fit: cover;">
                                    <?php else: ?>
                                        <i class="fas fa-user-tie fa-2x text-secondary"></i>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($instructor->name_ar); ?></td>
                                <td><?php echo e($instructor->name_en ?: '-'); ?></td>
                                <td><?php echo e($instructor->title ?: '-'); ?></td>
                                <td><?php echo e($instructor->email ?: '-'); ?></td>
                                <td><?php echo e($instructor->faculty->name_ar ?? 'غير محدد'); ?></td>
                                <td>
                                    <?php if($instructor->is_active): ?>
                                        <span class="badge bg-success">نشط</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">غير نشط</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.instructors.show', $instructor)); ?>" class="btn btn-sm btn-info" title="عرض"><i class="fas fa-eye"></i></a>
                                    <a href="<?php echo e(route('admin.instructors.edit', $instructor)); ?>" class="btn btn-sm btn-primary" title="تعديل"><i class="fas fa-edit"></i></a>
                                    <form action="<?php echo e(route('admin.instructors.destroy', $instructor)); ?>" method="POST" class="d-inline" onsubmit="return confirm('هل أنت متأكد من رغبتك في حذف هذا المدرس؟');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" title="حذف"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <?php echo e($instructors->appends(request()->query())->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/instructors/index.blade.php ENDPATH**/ ?>