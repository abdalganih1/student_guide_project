<?php $__env->startSection('title', 'تفاصيل الوسيط: ' . ($universityFacility->title_ar ?: 'وسيط #' . $universityFacility->id) ); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1><i class="fas fa-eye me-2"></i>تفاصيل وسيط جامعي</h1>
        <div>
            <a href="<?php echo e(route('admin.university-facilities.edit', $universityFacility)); ?>" class="btn btn-primary"><i class="fas fa-edit me-1"></i> تعديل</a>
            <a href="<?php echo e(route('admin.university-facilities.index')); ?>" class="btn btn-secondary">العودة إلى القائمة</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <?php if($universityFacility->file_url): ?>
            <div class="mb-3 text-center">
                <?php if($universityFacility->media_type == 'image'): ?>
                    <img src="<?php echo e(Storage::url($universityFacility->file_url)); ?>" alt="<?php echo e($universityFacility->title_ar ?: 'صورة'); ?>" class="img-fluid" style="max-height: 400px; border: 1px solid #ddd; padding: 5px;">
                <?php elseif($universityFacility->media_type == 'video'): ?>
                    <video controls width="100%" style="max-width: 600px;">
                        <source src="<?php echo e(Storage::url($universityFacility->file_url)); ?>" type="<?php echo e(Storage::mimeType($universityFacility->file_url)); ?>">
                        متصفحك لا يدعم عرض الفيديو.
                    </video>
                <?php elseif($universityFacility->media_type == 'document'): ?>
                    <p><a href="<?php echo e(Storage::url($universityFacility->file_url)); ?>" target="_blank" class="btn btn-info"><i class="fas fa-download me-1"></i> تحميل المستند (<?php echo e(basename($universityFacility->file_url)); ?>)</a></p>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <dl class="row">
                <dt class="col-sm-3">المعرف:</dt>
                <dd class="col-sm-9"><?php echo e($universityFacility->id); ?></dd>

                <dt class="col-sm-3">العنوان (عربي):</dt>
                <dd class="col-sm-9"><?php echo e($universityFacility->title_ar ?: '-'); ?></dd>

                <dt class="col-sm-3">العنوان (إنجليزي):</dt>
                <dd class="col-sm-9"><?php echo e($universityFacility->title_en ?: '-'); ?></dd>

                <dt class="col-sm-3">نوع الوسيط:</dt>
                <dd class="col-sm-9"><?php echo e($mediaTypes[$universityFacility->media_type] ?? $universityFacility->media_type); ?></dd>

                <dt class="col-sm-3">التصنيف:</dt>
                <dd class="col-sm-9"><?php echo e($universityFacility->category ?: '-'); ?></dd>

                <dt class="col-sm-3">الكلية المرتبطة:</dt>
                <dd class="col-sm-9"><?php echo e($universityFacility->faculty->name_ar ?? '-'); ?></dd>

                <dt class="col-sm-3">الوصف (عربي):</dt>
                <dd class="col-sm-9"><?php echo e($universityFacility->description_ar ?: '-'); ?></dd>

                <dt class="col-sm-3">الوصف (إنجليزي):</dt>
                <dd class="col-sm-9"><?php echo e($universityFacility->description_en ?: '-'); ?></dd>

                <dt class="col-sm-3">رُفع بواسطة:</dt>
                <dd class="col-sm-9"><?php echo e($universityFacility->uploadedByAdmin->username ?? '-'); ?></dd>

                <dt class="col-sm-3">تاريخ الرفع:</dt>
                <dd class="col-sm-9"><?php echo e($universityFacility->created_at->translatedFormat('l, d F Y H:i')); ?></dd>

                <dt class="col-sm-3">آخر تحديث:</dt>
                <dd class="col-sm-9"><?php echo e($universityFacility->updated_at->translatedFormat('l, d F Y H:i')); ?></dd>
            </dl>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/university_facilities/show.blade.php ENDPATH**/ ?>