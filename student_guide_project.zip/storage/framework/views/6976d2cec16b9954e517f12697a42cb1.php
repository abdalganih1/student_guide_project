<?php $__env->startSection('title', 'تفاصيل الاختصاص: ' . $specialization->name_ar); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1><i class="fas fa-eye me-2"></i>تفاصيل الاختصاص: <?php echo e($specialization->name_ar); ?></h1>
        <div>
            <a href="<?php echo e(route('admin.specializations.edit', $specialization)); ?>" class="btn btn-primary"><i class="fas fa-edit me-1"></i> تعديل</a>
            <a href="<?php echo e(route('admin.specializations.index')); ?>" class="btn btn-secondary">العودة إلى القائمة</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>المعرف:</strong> <?php echo e($specialization->id); ?></p>
                    <p><strong>الاسم (عربي):</strong> <?php echo e($specialization->name_ar); ?></p>
                    <p><strong>الاسم (إنجليزي):</strong> <?php echo e($specialization->name_en ?: '-'); ?></p>
                    <p><strong>الكلية:</strong> <?php echo e($specialization->faculty->name_ar ?? 'غير محدد'); ?></p>
                    <p><strong>الحالة:</strong>
                        <?php if($specialization->status == 'published'): ?> <span class="badge bg-success">منشور</span>
                        <?php elseif($specialization->status == 'draft'): ?> <span class="badge bg-warning text-dark">مسودة</span>
                        <?php else: ?> <span class="badge bg-secondary"><?php echo e($specialization->status); ?></span>
                        <?php endif; ?>
                    </p>
                </div>
                <div class="col-md-6">
                    <p><strong>تم إنشاؤه بواسطة:</strong> <?php echo e($specialization->createdByAdmin->name_ar ?? '-'); ?> (<?php echo e($specialization->createdByAdmin->username ?? ''); ?>)</p>
                    <p><strong>تاريخ الإنشاء:</strong> <?php echo e($specialization->created_at->translatedFormat('l, d F Y H:i')); ?></p>
                    <p><strong>آخر تحديث بواسطة:</strong> <?php echo e($specialization->lastUpdatedByAdmin->name_ar ?? '-'); ?> (<?php echo e($specialization->lastUpdatedByAdmin->username ?? ''); ?>)</p>
                    <p><strong>تاريخ آخر تحديث:</strong> <?php echo e($specialization->updated_at->translatedFormat('l, d F Y H:i')); ?></p>
                </div>
            </div>
            <hr>
            <div>
                <h5>الوصف (عربي):</h5>
                <p><?php echo e($specialization->description_ar); ?></p>
            </div>
            <?php if($specialization->description_en): ?>
            <hr>
            <div>
                <h5>الوصف (إنجليزي):</h5>
                <p><?php echo e($specialization->description_en); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h4><i class="fas fa-book me-2"></i>المقررات التابعة لهذا الاختصاص (<?php echo e($specialization->courses->count()); ?>)</h4>
        </div>
        <div class="card-body">
            <?php if($specialization->courses->isEmpty()): ?>
                <p class="text-muted">لا توجد مقررات مرتبطة بهذا الاختصاص حالياً.</p>
            <?php else: ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $specialization->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <a href="<?php echo e(route('admin.courses.show', $course)); ?>"><?php echo e($course->name_ar); ?> (<?php echo e($course->code); ?>)</a>
                            <span class="badge bg-info rounded-pill"><?php echo e($course->semester_display_info); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
             <div class="mt-3">
                <a href="<?php echo e(route('admin.courses.create', ['specialization_id' => $specialization->id])); ?>" class="btn btn-outline-success btn-sm">
                    <i class="fas fa-plus me-1"></i> إضافة مقرر جديد لهذا الاختصاص
                </a>
            </div>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h4><i class="fas fa-project-diagram me-2"></i>مشاريع التخرج التابعة لهذا الاختصاص (<?php echo e($specialization->projects->count()); ?>)</h4>
        </div>
        <div class="card-body">
            <?php if($specialization->projects->isEmpty()): ?>
                <p class="text-muted">لا توجد مشاريع تخرج مرتبطة بهذا الاختصاص حالياً.</p>
            <?php else: ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $specialization->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <a href="<?php echo e(route('admin.projects.show', $project)); ?>"><?php echo e($project->title_ar); ?></a> - <?php echo e($project->year); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <div class="mt-3">
                <a href="<?php echo e(route('admin.projects.create', ['specialization_id' => $specialization->id])); ?>" class="btn btn-outline-success btn-sm">
                    <i class="fas fa-plus me-1"></i> إضافة مشروع تخرج جديد لهذا الاختصاص
                </a>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projects\2024\مشاريع\الجامعة الوطنية الخاصة\تخرج\2025\فصل ثاني\بتول - ضياء\التنفيذ العملي\student_guide_project\resources\views/admin/specializations/show.blade.php ENDPATH**/ ?>